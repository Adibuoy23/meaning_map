# meaning_map
 A python package to generate and analyse meaning maps from images of natural scenes

This package provides the code for the following:
* Creating scene patches -  
